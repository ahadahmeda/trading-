package com.ahad.fxai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("fx", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setPadding(0, dp(14), 0, dp(4))
        }

        col.addView(TextView(this).apply { text = "FX AI"; textSize = 26f })
        col.addView(TextView(this).apply {
            text = "TradingView-তে পেয়ার খুলুন, ভাসমান AI বাটনে চাপ দিন। বাকি কাজ অ্যাপ করবে।"
            textSize = 14f
        })

        col.addView(label("Gemini API key (aistudio.google.com থেকে ফ্রি)"))
        val key = EditText(this).apply {
            setText(p.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "AIza..."
        }
        col.addView(key)

        col.addView(label("মডেল (বদলানোর দরকার নেই)"))
        val model = EditText(this).apply {
            setText(p.getString("model", "gemini-3.8-flash"))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        col.addView(model)

        col.addView(label("অতিরিক্ত কমান্ড (ঐচ্ছিক, যেমন: শুধু SMC অনুযায়ী দেখো)"))
        val cmd = EditText(this).apply { setText(p.getString("cmd", "")) }
        col.addView(cmd)

        col.addView(label("লট সাইজ (SL/TP-র ডলার হিসাবের জন্য)"))
        val lot = EditText(this).apply {
            setText(p.getString("lot", "0.01"))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        col.addView(lot)

        val auto = CheckBox(this).apply {
            text = "নিজে নিজে টাইমফ্রেম বদলাবে (1D, 4H, 1H, 15m)"
            isChecked = p.getBoolean("auto", true)
        }
        col.addView(auto)
        val always = CheckBox(this).apply {
            text = "সব অ্যাপে বাটন দেখাও (শুধু পরীক্ষার জন্য)"
            isChecked = p.getBoolean("always", false)
        }
        col.addView(always)

        col.addView(Button(this).apply {
            text = "সেভ করুন"
            setOnClickListener {
                p.edit()
                    .putString("key", key.text.toString().trim())
                    .putString("model", model.text.toString().trim())
                    .putString("cmd", cmd.text.toString().trim())
                    .putString("lot", lot.text.toString().trim().ifBlank { "0.01" })
                    .putBoolean("auto", auto.isChecked)
                    .putBoolean("always", always.isChecked)
                    .apply()
                Toast.makeText(this@MainActivity, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(Button(this).apply {
            text = "Accessibility সেটিংস খুলুন (FX AI চালু করুন)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(TextView(this).apply {
            text = "ধাপ: ১) key সেভ ২) Accessibility-তে FX AI চালু ৩) TradingView খুলে পেয়ার দিন ৪) AI বাটনে চাপ।\n\n" +
                "এটা শিক্ষামূলক বিশ্লেষণ, আর্থিক পরামর্শ নয়। সবসময় স্টপ লস দিন, আগে ডেমোতে চালান।"
            textSize = 13f
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }
}
