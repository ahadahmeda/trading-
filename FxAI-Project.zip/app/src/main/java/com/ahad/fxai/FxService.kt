package com.ahad.fxai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.ScrollView
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class FxService : AccessibilityService() {

    private val TV = "com.tradingview.tradingviewapp"

    // টাইমফ্রেমের নাম ও চার্টে যে লেখাগুলো খোঁজা হবে (দরকারে এখানে বদলান)
    private val TFS = listOf(
        "1D" to listOf("1D", "D", "1d"),
        "4H" to listOf("4h", "4H", "240"),
        "1H" to listOf("1h", "1H", "60"),
        "15m" to listOf("15m", "15M", "15")
    )

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var btn: TextView? = null
    private var panel: LinearLayout? = null
    private var resultView: TextView? = null
    private var imageView: ImageView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("fx", MODE_PRIVATE)
        buildButton()
        buildPanel()
        if (prefs.getBoolean("always", false)) btn?.visibility = View.VISIBLE
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || busy) return
        val show = pkg == TV || prefs.getBoolean("always", false)
        btn?.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) panel?.visibility = View.GONE
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { btn?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildButton() {
        val b = TextView(this).apply {
            text = "AI"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE60A84FF.toInt())
            }
            visibility = View.GONE
        }
        val p = WindowManager.LayoutParams(
            dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(260) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = ev.rawX; ty = ev.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - tx).toInt(); val dy = (ev.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) startAnalysis(); true }
                else -> false
            }
        }
        wm.addView(b, p)
        btn = b
    }

    private fun buildPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xF2101418.toInt())
            }
            visibility = View.GONE
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "FX AI বিশ্লেষণ"; setTextColor(Color.WHITE); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 20f
            setPadding(dp(16), 0, dp(4), 0)
            setOnClickListener { box.visibility = View.GONE }
        })
        box.addView(header)

        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(8), 0, 0)
        }
        val iv = ImageView(this).apply {
            adjustViewBounds = true
            setPadding(0, dp(10), 0, 0)
            visibility = View.GONE
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(tv)
        content.addView(iv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val sv = ScrollView(this).apply { addView(content) }
        box.addView(sv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))

        val dm = resources.displayMetrics
        val p = WindowManager.LayoutParams(
            dm.widthPixels - dp(16), (dm.heightPixels * 0.6).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(48) }
        wm.addView(box, p)
        panel = box
        resultView = tv
        imageView = iv
        panelParams = p
    }

    private fun setText(t: String) = ui.post {
        resultView?.text = t
        panel?.visibility = View.VISIBLE
    }

    private fun onUiWait(f: () -> Unit) {
        val l = CountDownLatch(1)
        ui.post { f(); l.countDown() }
        l.await(3, TimeUnit.SECONDS)
    }

    // ---------- বিশ্লেষণের ধাপ ----------
    private fun startAnalysis() {
        if (busy) return
        val key = prefs.getString("key", "")?.trim() ?: ""
        if (key.isEmpty()) {
            setText("API key দেওয়া হয়নি। FX AI অ্যাপ খুলে key বসিয়ে সেভ করুন।")
            return
        }
        busy = true
        ui.post { imageView?.visibility = View.GONE }
        setText("শুরু হচ্ছে…")
        Thread {
            try {
                runAnalysis(key)
            } catch (e: Exception) {
                setText("ত্রুটি: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                busy = false
            }
        }.start()
    }

    private fun runAnalysis(key: String) {
        val model = (prefs.getString("model", "") ?: "").ifBlank { "gemini-3.8-flash" }
        val cmd = prefs.getString("cmd", "") ?: ""
        val auto = prefs.getBoolean("auto", true)
        val shots = ArrayList<Pair<String, String>>()

        if (auto) {
            for ((label, cands) in TFS) {
                setText("টাইমফ্রেম " + label + " স্ক্যান হচ্ছে…")
                if (!switchTf(cands)) continue
                Thread.sleep(2200)
                capture()?.let { shots.add(label to it) }
                Thread.sleep(1200)
            }
        }
        if (shots.isEmpty()) {
            setText("বর্তমান চার্ট স্ক্যান হচ্ছে…")
            capture()?.let { shots.add("বর্তমান" to it) }
        }
        if (shots.isEmpty()) {
            setText("স্ক্রিনশট নেওয়া যায়নি। Accessibility সার্ভিস চালু আছে কিনা দেখুন।")
            return
        }
        setText("AI বিশ্লেষণ করছে (" + shots.size + "টি চার্ট)… একটু অপেক্ষা করুন")
        val lots = (prefs.getString("lot", "0.01") ?: "0.01").toDoubleOrNull() ?: 0.01
        val r = Gemini.analyze(key, model, shots, cmd) { s -> setText(s) }
        if (!r.ok) {
            setText(r.text)
            return
        }
        val text = Report.render(r.text, lots)
        setText(text)
        try {
            val bmp = Annot.make(shots.last().second, r.text, lots)
            if (bmp != null) {
                val uri = saveImage(bmp)
                showImage(bmp, uri)
                setText(text + "\n\nছবি গ্যালারিতে সেভ হয়েছে (Pictures/FxAI)। ছবিতে চাপ দিলে খুলবে।\n" +
                    "ছবির দাগগুলো AI-র আন্দাজে আঁকা, চার্টের সাথে মিলিয়ে নেবেন।")
            }
        } catch (e: Exception) {
            setText(text + "\n\n(ছবি বানানো যায়নি: " + (e.message ?: "") + ")")
        }
    }

    private fun saveImage(bmp: Bitmap): Uri? {
        val name = "FXAI_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FxAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return uri
    }

    private fun showImage(bmp: Bitmap, uri: Uri?) {
        ui.post {
            imageView?.apply {
                setImageBitmap(bmp)
                visibility = View.VISIBLE
                setOnClickListener {
                    if (uri != null) {
                        try {
                            startActivity(
                                Intent(Intent.ACTION_VIEW)
                                    .setDataAndType(uri, "image/jpeg")
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (_: Exception) {
                        }
                    }
                }
            }
            val pv = panel
            val pp = panelParams
            if (pv != null && pp != null) {
                pp.height = (resources.displayMetrics.heightPixels * 0.85).toInt()
                try { wm.updateViewLayout(pv, pp) } catch (_: Exception) {}
            }
        }
    }

    private fun switchTf(cands: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (c in cands) {
            val nodes = root.findAccessibilityNodeInfosByText(c) ?: continue
            for (n in nodes) {
                val t = n.text?.toString()?.trim() ?: ""
                val d = n.contentDescription?.toString()?.trim() ?: ""
                if (t.equals(c, true) || d.equals(c, true)) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable) x = x.parent
                    if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
            }
        }
        return false
    }

    private fun capture(): String? {
        onUiWait { btn?.visibility = View.INVISIBLE; panel?.visibility = View.INVISIBLE }
        Thread.sleep(400)
        var result: String? = null
        val latch = CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(s: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(s.hardwareBuffer, s.colorSpace)
                    val sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    s.hardwareBuffer.close()
                    if (sw != null) {
                        val maxW = 1080
                        val bmp = if (sw.width > maxW)
                            Bitmap.createScaledBitmap(sw, maxW, sw.height * maxW / sw.width, true)
                        else sw
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 75, out)
                        result = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (_: Exception) {
                }
                latch.countDown()
            }

            override fun onFailure(errorCode: Int) {
                latch.countDown()
            }
        })
        latch.await(8, TimeUnit.SECONDS)
        onUiWait { btn?.visibility = View.VISIBLE; panel?.visibility = View.VISIBLE }
        return result
    }
}
