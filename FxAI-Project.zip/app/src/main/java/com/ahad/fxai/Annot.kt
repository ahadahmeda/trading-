package com.ahad.fxai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Base64
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// স্ক্রিনশটের ওপর এন্ট্রি, SL, TP, সাপোর্ট-রেজিস্ট্যান্স, জোন ও ট্রেন্ডলাইন আঁকে
object Annot {
    private val BLUE = 0xFF1E88E5.toInt()
    private val RED = 0xFFD32F2F.toInt()
    private val GREEN = 0xFF2E7D32.toInt()
    private val YELLOW = 0xFFF9A825.toInt()
    private val GRAY = 0xFF455A64.toInt()

    private fun tag(c: Canvas, text: String, x: Float, bottom: Float, bg: Int, k: Float, right: Boolean) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 22f * k
            typeface = Typeface.DEFAULT_BOLD
        }
        val w = tp.measureText(text)
        val pad = 6f * k
        val h = tp.textSize + pad * 2
        val left = max(0f, if (right) x - w - pad * 2 else x)
        val top = max(0f, bottom - h)
        val bgp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
        c.drawRoundRect(RectF(left, top, left + w + pad * 2, top + h), 6f * k, 6f * k, bgp)
        c.drawText(text, left + pad, top + pad + tp.textSize * 0.82f, tp)
    }

    fun make(b64: String, raw: String, lots: Double): Bitmap? {
        val j = Report.parse(raw) ?: return null
        val bytes = Base64.decode(b64, Base64.NO_WRAP)
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true) ?: return null
        val c = Canvas(bmp)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val k = w / 1080f

        val pair = j.optString("pair", "").uppercase().filter { it.isLetter() }
        val signal = j.optString("signal", "").uppercase().replace(" ", "_")
        val dec = Calc.priceDecimals(pair)
        val ch = j.optJSONObject("chart")

        // দামের স্কেল: দুটো দাম আর তাদের y অবস্থান থেকে দাম→পিক্সেল হিসাব
        var pa = Double.NaN; var ya = Double.NaN; var pb = Double.NaN; var yb = Double.NaN
        val sc = ch?.optJSONArray("scale")
        if (sc != null && sc.length() >= 2) {
            val a = sc.optJSONObject(0)
            val b = sc.optJSONObject(1)
            if (a != null && b != null) {
                pa = a.optDouble("price", Double.NaN); ya = a.optDouble("y", Double.NaN)
                pb = b.optDouble("price", Double.NaN); yb = b.optDouble("y", Double.NaN)
            }
        }
        val mapOk = !pa.isNaN() && !pb.isNaN() && !ya.isNaN() && !yb.isNaN() &&
            pa != pb && ya != yb && ((pb - pa) * (yb - ya) < 0)

        fun yPx(price: Double): Float = ((ya + (price - pa) * (yb - ya) / (pb - pa)) / 1000.0 * h).toFloat()

        var axisX = ch?.optDouble("axis_x", 880.0) ?: 880.0
        if (axisX.isNaN() || axisX < 500.0 || axisX > 990.0) axisX = 880.0
        val ax = (axisX / 1000.0 * w).toFloat()

        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

        fun hline(price: Double, color: Int, text: String, dashed: Boolean) {
            if (!mapOk || price.isNaN()) return
            val y = yPx(price)
            if (y < 0f || y > h) return
            lp.color = color
            lp.strokeWidth = 3f * k
            lp.pathEffect = if (dashed) DashPathEffect(floatArrayOf(20f * k, 12f * k), 0f) else null
            c.drawLine(0f, y, ax, y, lp)
            tag(c, text, ax - 6f * k, y - 2f * k, color, k, true)
        }

        // সাপ্লাই/ডিমান্ড জোন
        val zones = ch?.optJSONArray("zones")
        if (mapOk && zones != null) {
            for (i in 0 until min(zones.length(), 3)) {
                val z = zones.optJSONObject(i) ?: continue
                val t = z.optDouble("top", Double.NaN)
                val b = z.optDouble("bottom", Double.NaN)
                if (t.isNaN() || b.isNaN()) continue
                val y1 = yPx(max(t, b))
                val y2 = yPx(min(t, b))
                if (y2 < 0f || y1 > h) continue
                val type = z.optString("type", "").lowercase()
                val col = if (type.contains("supply") || type.contains("resist")) RED else GREEN
                val fp = Paint().apply { color = col; alpha = 64 }
                c.drawRect(0f, max(0f, y1), ax, min(h, y2), fp)
                tag(c, z.optString("label", type), 8f * k, max(0f, y1) + 34f * k, col, k, false)
            }
        }

        // সাপোর্ট/রেজিস্ট্যান্স
        val lv = ch?.optJSONArray("levels")
        if (lv != null) {
            for (i in 0 until min(lv.length(), 5)) {
                val o = lv.optJSONObject(i) ?: continue
                val p = o.optDouble("price", Double.NaN)
                val type = o.optString("type", "").lowercase()
                val col = if (type.contains("resist") || type.contains("supply")) RED else GREEN
                hline(p, col, o.optString("label", "") + " " + Calc.f(p, dec), true)
            }
        }

        // ট্রেন্ডলাইন
        val tl = ch?.optJSONArray("trendlines")
        if (tl != null) {
            for (i in 0 until min(tl.length(), 3)) {
                val o = tl.optJSONObject(i) ?: continue
                val x1 = o.optDouble("x1", Double.NaN); val y1 = o.optDouble("y1", Double.NaN)
                val x2 = o.optDouble("x2", Double.NaN); val y2 = o.optDouble("y2", Double.NaN)
                if (x1.isNaN() || y1.isNaN() || x2.isNaN() || y2.isNaN()) continue
                val px1 = (x1 / 1000.0 * w).toFloat(); val py1 = (y1 / 1000.0 * h).toFloat()
                val px2 = (x2 / 1000.0 * w).toFloat(); val py2 = (y2 / 1000.0 * h).toFloat()
                var ex = px2
                var ey = py2
                if (abs(px2 - px1) > 1f && px2 < ax) {
                    val m = (py2 - py1) / (px2 - px1)
                    ex = ax
                    ey = py2 + m * (ax - px2)
                }
                lp.color = YELLOW
                lp.strokeWidth = 3.5f * k
                lp.pathEffect = null
                c.drawLine(px1, py1, ex, ey, lp)
                tag(c, o.optString("label", "Trend"), px1, py1 - 4f * k, YELLOW, k, false)
            }
        }

        // এন্ট্রি, SL, TP (সবার ওপরে)
        val isTrade = signal == "BUY" || signal == "SELL"
        if (isTrade) {
            val entry = j.optDouble("entry", Double.NaN)
            val sl = j.optDouble("sl", Double.NaN)
            val tp1 = j.optDouble("tp1", Double.NaN)
            val tp2 = j.optDouble("tp2", Double.NaN)
            if (!entry.isNaN()) {
                hline(entry, BLUE, "ENTRY " + Calc.f(entry, dec), false)
                if (!sl.isNaN()) hline(sl, RED, "SL " + Calc.f(sl, dec) + Report.amountText(pair, entry, sl, lots, true), false)
                if (!tp1.isNaN()) hline(tp1, GREEN, "TP1 " + Calc.f(tp1, dec) + Report.amountText(pair, entry, tp1, lots, false), false)
                if (!tp2.isNaN()) hline(tp2, GREEN, "TP2 " + Calc.f(tp2, dec) + Report.amountText(pair, entry, tp2, lots, false), false)
            }
        }

        // হেডার ও নোট
        val headBg = when (signal) { "BUY" -> GREEN; "SELL" -> RED; else -> GRAY }
        tag(c, pair + "   " + signal.replace("_", " "), 12f * k, 72f * k, headBg, k, false)
        if (isTrade && !mapOk) {
            tag(c, "Price scale unreadable: levels not drawn", 12f * k, h - 90f * k, GRAY, k, false)
        }
        tag(c, "FX AI - approximate, verify on chart", 12f * k, h - 40f * k, GRAY, k, false)
        return bmp
    }
}
