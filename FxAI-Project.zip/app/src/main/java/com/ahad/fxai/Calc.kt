package com.ahad.fxai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs

object Calc {

    fun f(v: Double, n: Int): String = String.format(Locale.US, "%." + n + "f", v)

    fun pipSize(pair: String): Double = if (pair.endsWith("JPY")) 0.01 else 0.0001

    fun priceDecimals(pair: String): Int = when {
        pair.startsWith("XAU") -> 2
        pair.endsWith("JPY") -> 3
        else -> 5
    }

    // দামের ১.০ নড়াচড়ায় কত ডলার লাভ/ক্ষতি (নির্দিষ্ট লটে)। না পারলে null।
    fun unitUsd(pair: String, entry: Double, lots: Double): Double? {
        if (pair.startsWith("XAU")) return 100.0 * lots
        if (pair.length < 6) return null
        val base = pair.substring(0, 3)
        val quote = pair.substring(3, 6)
        val q = 100000.0 * lots
        if (quote == "USD") return q
        if (base == "USD") return if (entry > 0) q / entry else null
        val rate = fetchRate(quote) ?: return null
        return q / rate
    }

    private var ratesCache: JSONObject? = null
    private var ratesTime = 0L

    // ১ USD = কত কোট-কারেন্সি (ক্রস পেয়ারের জন্য, ফ্রি সার্ভিস)
    private fun fetchRate(cur: String): Double? {
        return try {
            val now = System.currentTimeMillis()
            if (ratesCache == null || now - ratesTime > 600000L) {
                val c = (URL("https://open.er-api.com/v6/latest/USD").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                ratesCache = JSONObject(txt).getJSONObject("rates")
                ratesTime = now
            }
            val r = ratesCache?.optDouble(cur, Double.NaN) ?: Double.NaN
            if (r.isNaN() || r <= 0) null else r
        } catch (e: Exception) {
            null
        }
    }
}

object Report {

    private fun clean(raw: String): String {
        var s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a >= 0 && b > a) s = s.substring(a, b + 1)
        return s
    }

    fun parse(raw: String): JSONObject? = try {
        JSONObject(clean(raw))
    } catch (e: Exception) {
        null
    }

    private fun num(j: JSONObject, k: String): Double = j.optDouble(k, Double.NaN)

    // ছবির লেবেলের জন্য: " -$3.00" বা " +$6.00"
    fun amountText(pair: String, entry: Double, level: Double, lots: Double, loss: Boolean): String {
        val unit = Calc.unitUsd(pair, entry, lots) ?: return ""
        return (if (loss) " -\$" else " +\$") + Calc.f(abs(level - entry) * unit, 2)
    }

    fun render(raw: String, lots: Double): String {
        val j = parse(raw) ?: return raw.replace("**", "").trim()

        val pair = j.optString("pair", "").uppercase().filter { it.isLetter() }
        val signal = j.optString("signal", "").uppercase().replace(" ", "_")
        val conf = j.optString("confidence", "")
        val tfs = j.optString("timeframes", "")
        val reason = j.optString("reason", "")
        val be = j.optString("breakeven", "")
        val inv = j.optString("invalidation", "")

        val icon = when (signal) { "BUY" -> "🟢"; "SELL" -> "🔴"; else -> "⚪" }
        val sb = StringBuilder()
        sb.append(icon).append(" ").append(pair).append("   ").append(signal.replace("_", " ")).append("\n")
        if (conf.isNotBlank()) sb.append("কনফিডেন্স: ").append(conf).append("\n")
        if (tfs.isNotBlank()) sb.append("\n").append(tfs).append("\n")

        val entry = num(j, "entry"); val sl = num(j, "sl")
        val tp1 = num(j, "tp1"); val tp2 = num(j, "tp2")
        val isTrade = (signal == "BUY" || signal == "SELL") && !entry.isNaN() && !sl.isNaN() && !tp1.isNaN()

        if (isTrade) {
            val buy = signal == "BUY"
            val valid = if (buy) (sl < entry && tp1 > entry) else (sl > entry && tp1 < entry)
            if (!valid) {
                sb.append("\n⚠ সংখ্যায় গরমিল আছে (SL/TP ভুল দিকে)। এই সিগন্যালে ট্রেড নেবেন না।\n")
            }
            val dec = Calc.priceDecimals(pair)
            val unit = Calc.unitUsd(pair, entry, lots)
            sb.append("\n").append(Calc.f(lots, 2)).append(" লটের হিসাব:\n")
            sb.append("এন্ট্রি: ").append(Calc.f(entry, dec)).append("\n")
            sb.append(leg("SL", sl, entry, unit, pair, dec, true))
            sb.append(leg("TP1", tp1, entry, unit, pair, dec, false))
            if (!tp2.isNaN()) sb.append(leg("TP2", tp2, entry, unit, pair, dec, false))

            val risk = abs(entry - sl)
            if (risk > 0) {
                sb.append("RR (TP1): 1:").append(Calc.f(abs(tp1 - entry) / risk, 1)).append("\n")
                if (abs(tp1 - entry) / risk < 1.5) sb.append("⚠ RR কম, সতর্ক থাকুন।\n")
            }
            if (unit == null) {
                sb.append("(এই পেয়ারের ডলার রেট পাওয়া যায়নি, তাই অ্যামাউন্ট দেখানো গেল না)\n")
            }
        }

        if (be.isNotBlank()) sb.append("\nব্রেক ইভেন: ").append(be).append("\n")
        if (inv.isNotBlank()) sb.append("বাতিল হবে: ").append(inv).append("\n")
        if (reason.isNotBlank()) sb.append("\nকারণ: ").append(reason).append("\n")
        sb.append("\nশিক্ষামূলক বিশ্লেষণ, আর্থিক পরামর্শ নয়। SL ছাড়া ট্রেড নেবেন না।")
        return sb.toString()
    }

    private fun leg(
        name: String, level: Double, entry: Double, unit: Double?,
        pair: String, dec: Int, loss: Boolean
    ): String {
        val d = abs(level - entry)
        val dist = if (pair.startsWith("XAU")) "দূরত্ব " + Calc.f(d, 2)
        else Calc.f(d / Calc.pipSize(pair), 1) + " pip"
        val amt = if (unit == null) "" else
            (if (loss) "  ক্ষতি ≈ -\$" else "  লাভ ≈ +\$") + Calc.f(d * unit, 2)
        return name + ": " + Calc.f(level, dec) + "  (" + dist + ")" + amt + "\n"
    }
}
