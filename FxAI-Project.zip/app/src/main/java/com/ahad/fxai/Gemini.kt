package com.ahad.fxai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {

    private fun prompt(cmd: String): String {
        val base = """
তুমি একজন অভিজ্ঞ ফরেক্স ট্রেডিং অ্যানালিস্ট। নিচে একই ফরেক্স পেয়ারের TradingView চার্টের স্ক্রিনশট দেওয়া হয়েছে, প্রতিটার আগে টাইমফ্রেমের নাম লেখা আছে।

নিয়ম:
- পেয়ারের নাম ও দাম চার্ট থেকে পড়ো। শুধু চার্টে যা স্পষ্ট দেখা যায় তার ওপর ভিত্তি করো। দাম বা লেভেল বানিয়ে বোলো না।
- পদ্ধতি: Multi-timeframe top-down। হায়ার টাইমফ্রেমে ট্রেন্ড ও স্ট্রাকচার (HH-HL / LH-LL), key সাপোর্ট-রেজিস্ট্যান্স, সাপ্লাই-ডিমান্ড জোন, লিকুইডিটি। লোয়ার টাইমফ্রেমে এন্ট্রি কনফার্মেশন (ক্যান্ডেল প্যাটার্ন, ব্রেকআউট ও রিটেস্ট)।
- চার্টে EMA, RSI, MACD বা ভলিউম দেখা গেলে কনফ্লুয়েন্স হিসেবে ব্যবহার করো। না দেখা গেলে লেখো "ইন্ডিকেটর দৃশ্যমান নয়"।
- সেটআপ পরিষ্কার না হলে সোজা বলো NO TRADE এবং কারণ দাও। জোর করে সিগন্যাল দিও না।
- মার্কডাউন চিহ্ন (** বা #) ব্যবহার কোরো না, সাধারণ টেক্সটে লেখো।

আউটপুট বাংলায়, ছোট ও গোছানো, এই কাঠামোয়:
১) পেয়ার ও বর্তমান দাম
২) টাইমফ্রেম অনুযায়ী ট্রেন্ড (প্রতিটা এক লাইনে)
৩) সিগন্যাল: BUY / SELL / NO TRADE (কনফিডেন্স: কম / মাঝারি / বেশি)
৪) এন্ট্রি জোন (কোন দাম থেকে)
৫) স্টপ লস
৬) টার্গেট TP1, TP2 (আনুমানিক RR সহ)
৭) ব্রেক ইভেন: কোন দামে পৌঁছালে SL এন্ট্রিতে সরাবে, কখন পার্শিয়াল প্রফিট নেবে
৮) কখন সেটআপ বাতিল হবে
৯) রিস্ক: একটি ট্রেডে অ্যাকাউন্টের ১-২% এর বেশি নয়
সবশেষে এক লাইনে লেখো: এটা শিক্ষামূলক বিশ্লেষণ, আর্থিক পরামর্শ নয়।
""".trimIndent()
        return if (cmd.isBlank()) base else base + "\n\nব্যবহারকারীর অতিরিক্ত কমান্ড: " + cmd
    }

    fun analyze(key: String, model: String, shots: List<Pair<String, String>>, cmd: String): String {
        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt(cmd)))
        for ((label, b64) in shots) {
            parts.put(JSONObject().put("text", "টাইমফ্রেম: " + label))
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", b64)
                )
            )
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.3))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) return friendly(code, txt)

        val cands = JSONObject(txt).optJSONArray("candidates")
        val ps = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "AI কোনো উত্তর দেয়নি। আবার চেষ্টা করুন।"
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
        return sb.toString().replace("**", "").replace("##", "").trim()
    }

    private fun friendly(code: Int, txt: String): String {
        val msg = try {
            JSONObject(txt).optJSONObject("error")?.optString("message", "") ?: ""
        } catch (e: Exception) { "" }
        return when (code) {
            400 -> "API key ঠিক নেই বা অনুরোধ ভুল। key আবার চেক করুন।\n" + msg
            403 -> "API key কাজ করছে না (অনুমতি নেই)। নতুন key বানান।\n" + msg
            429 -> "ফ্রি লিমিট শেষ। কিছুক্ষণ পর আবার চেষ্টা করুন।"
            else -> "ত্রুটি " + code + ": " + msg
        }
    }
}
