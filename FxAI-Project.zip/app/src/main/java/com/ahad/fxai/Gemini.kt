package com.ahad.fxai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {

    class Reply(val ok: Boolean, val text: String)

    private fun prompt(cmd: String): String {
        val base = """
তুমি একজন অভিজ্ঞ ফরেক্স ট্রেডিং অ্যানালিস্ট। নিচে একই ফরেক্স পেয়ারের TradingView চার্টের স্ক্রিনশট দেওয়া হয়েছে, প্রতিটার আগে টাইমফ্রেমের নাম লেখা আছে।

নিয়ম:
- পেয়ারের নাম ও দাম চার্ট থেকে পড়ো। শুধু চার্টে যা স্পষ্ট দেখা যায় তার ওপর ভিত্তি করো। দাম বা লেভেল বানিয়ে বোলো না। দামগুলো চার্টের দামের স্কেলের সাথে মিলিয়ে দাও।
- পদ্ধতি: Multi-timeframe top-down। হায়ার টাইমফ্রেমে ট্রেন্ড ও স্ট্রাকচার (HH-HL / LH-LL), key সাপোর্ট-রেজিস্ট্যান্স, সাপ্লাই-ডিমান্ড জোন, লিকুইডিটি। লোয়ার টাইমফ্রেমে এন্ট্রি কনফার্মেশন (ক্যান্ডেল প্যাটার্ন, ব্রেকআউট ও রিটেস্ট)।
- চার্টে EMA, RSI, MACD বা ভলিউম দেখা গেলে কনফ্লুয়েন্স হিসেবে ব্যবহার করো।
- সেটআপ পরিষ্কার না হলে signal দাও NO_TRADE এবং reason-এ কারণ লেখো। জোর করে সিগন্যাল দিও না।
- BUY হলে sl < entry < tp1 < tp2 হতে হবে। SELL হলে sl > entry > tp1 > tp2। রিস্ক:রিওয়ার্ড অন্তত ১:১.৫।

আউটপুট শুধুমাত্র একটা JSON অবজেক্ট, অন্য কিছু লিখবে না। ফরম্যাট:
{"pair":"EURUSD","signal":"BUY অথবা SELL অথবা NO_TRADE","confidence":"কম অথবা মাঝারি অথবা বেশি","timeframes":"প্রতি টাইমফ্রেমের ট্রেন্ড এক লাইনে, বাংলায়","entry":1.12345,"sl":1.12000,"tp1":1.12800,"tp2":1.13200,"breakeven":"কোন দামে পৌঁছালে SL এন্ট্রিতে সরাবে, বাংলায়","invalidation":"কখন সেটআপ বাতিল, বাংলায়","reason":"২-৩ লাইনে কারণ, বাংলায়"}
দামগুলো শুধু সংখ্যা (কোনো চিহ্ন বা লেখা নয়)। NO_TRADE হলে entry, sl, tp1, tp2 হবে null।

এছাড়া একই JSON-এর ভেতরে "chart" নামে একটা অবজেক্ট দাও। এটা শুধু সর্বশেষ (শেষ) ছবির জন্য, যাতে অ্যাপ ছবির ওপর দাগ আঁকতে পারে। ছবির বাম-ওপর কোণ (0,0) আর ডান-নিচ কোণ (1000,1000) ধরে x ও y দাও। উদাহরণ:
"chart":{"scale":[{"price":1.12300,"y":300},{"price":1.11500,"y":700}],"axis_x":880,"levels":[{"price":1.12500,"type":"resistance","label":"R1"}],"zones":[{"top":1.12200,"bottom":1.12100,"type":"demand","label":"Demand"}],"trendlines":[{"x1":100,"y1":600,"x2":700,"y2":350,"label":"Trend"}]}
- scale: ডান পাশের দামের স্কেলে স্পষ্ট পড়া যায় এমন দুটো দাম ও তাদের y অবস্থান। দুটো দামের মধ্যে অন্তত অর্ধেক চার্টের দূরত্ব রাখো। উঁচু দামের y সংখ্যায় ছোট হবে।
- axis_x: ডান পাশের দামের সংখ্যাগুলো যে x থেকে শুরু।
- levels: সর্বোচ্চ ৫টা গুরুত্বপূর্ণ সাপোর্ট বা রেজিস্ট্যান্স (type: support বা resistance)।
- zones: সর্বোচ্চ ২টা সাপ্লাই বা ডিমান্ড জোন (type: supply বা demand)।
- trendlines: সর্বোচ্চ ৩টা ট্রেন্ডলাইন বা চ্যানেল, ক্যান্ডেলের ওপর যেখানে সত্যিই দেখা যায়। x1,y1 থেকে x2,y2।
- সব label ইংরেজিতে ও ছোট (সর্বোচ্চ ১০ অক্ষর)। যা স্পষ্ট দেখা যায় না তা বাদ দাও, আন্দাজে আঁকবে না।
""".trimIndent()
        return if (cmd.isBlank()) base else base + "\n\nব্যবহারকারীর অতিরিক্ত কমান্ড: " + cmd
    }

    private fun buildBody(shots: List<Pair<String, String>>, cmd: String): String {
        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt(cmd)))
        for ((label, b64) in shots) {
            parts.put(JSONObject().put("text", "টাইমফ্রেম: " + label))
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", b64)
                )
            )
        }
        return JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            .toString()
    }

    private fun call(key: String, model: String, body: String): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        return Pair(code, txt)
    }

    private fun extract(txt: String): String? {
        val cands = JSONObject(txt).optJSONArray("candidates")
        val ps = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return null
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
        val s = sb.toString().trim()
        return if (s.isEmpty()) null else s
    }

    // 503/429 এলে আবার চেষ্টা করে, দরকারে অন্য মডেলে চলে যায়
    fun analyze(
        key: String, model: String, shots: List<Pair<String, String>>, cmd: String,
        status: (String) -> Unit
    ): Reply {
        val models = listOf(model, "gemini-3.5-flash", "gemini-3.5-flash-lite")
            .filter { it.isNotBlank() }.distinct()
        val body = buildBody(shots, cmd)
        var last = "অজানা ত্রুটি"
        for (m in models) {
            for (attempt in 1..3) {
                status("AI বিশ্লেষণ করছে (" + m + ")… চেষ্টা " + attempt)
                val res: Pair<Int, String> = try {
                    call(key, m, body)
                } catch (e: Exception) {
                    Pair(-1, e.message ?: "নেটওয়ার্ক ত্রুটি")
                }
                val code = res.first
                val txt = res.second
                if (code in 200..299) {
                    val t = try { extract(txt) } catch (e: Exception) { null }
                    if (t != null) return Reply(true, t)
                    last = "AI কোনো উত্তর দেয়নি।"
                    break
                }
                last = friendly(code, txt)
                if (code == 400 || code == 401 || code == 403) return Reply(false, last)
                if (code == 404) break
                if (attempt < 3) Thread.sleep(attempt * 4000L)
            }
        }
        return Reply(false, last)
    }

    private fun friendly(code: Int, txt: String): String {
        val msg = try {
            JSONObject(txt).optJSONObject("error")?.optString("message", "") ?: ""
        } catch (e: Exception) { txt.take(200) }
        return when (code) {
            400 -> "API key ঠিক নেই বা অনুরোধ ভুল।\n" + msg
            401, 403 -> "API key কাজ করছে না। নতুন key বানান।\n" + msg
            404 -> "মডেল পাওয়া যায়নি। সেটিংসে মডেলের নাম বদলান।\n" + msg
            429 -> "ফ্রি লিমিট শেষ। কিছুক্ষণ পর আবার চেষ্টা করুন।"
            -1 -> "নেটওয়ার্ক সমস্যা: " + msg
            else -> "ত্রুটি " + code + ": " + msg
        }
    }
}
