FX AI - APK বানানোর ধাপ (GitHub দিয়ে, ফ্রি)

১) ZIP এক্সট্র্যাক্ট করুন (GitHub ওয়েবসাইট ZIP নিজে খোলে না)।
২) GitHub-এ New repository বানান, তারপর "uploading an existing file" চাপুন।
৩) FxAI ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার আপলোড করুন (app, build.gradle.kts, settings.gradle.kts, gradle.properties, .github ইত্যাদি)।
   যদি .github ফোল্ডার আপলোড না হয়: "Add file > Create new file" চাপুন, নামের ঘরে লিখুন
   .github/workflows/build.yml  এবং WORKFLOW-build.yml.txt ফাইলের লেখা পুরোটা কপি করে বসান, Commit করুন।
৪) Actions ট্যাব খুলুন। "Build APK" চলবে (৪-৮ মিনিট)। সবুজ টিক এলে ওই রানে ক্লিক করে নিচে Artifacts থেকে FxAI-APK ডাউনলোড করুন (ZIP আসবে, খুললে app-debug.apk)।
৫) APK ইনস্টল করুন। FX AI খুলে Gemini key বসিয়ে সেভ করুন।
৬) ফোন Settings > Accessibility > FX AI চালু করুন।
   Android 13+ হলে চালু করতে না পারলে: Settings > Apps > FX AI > উপরের ডানের ⋮ > "Allow restricted settings", তারপর আবার চালু করুন।
৭) TradingView খুলে পেয়ার দিন, ভাসমান AI বাটনে চাপ দিন।
